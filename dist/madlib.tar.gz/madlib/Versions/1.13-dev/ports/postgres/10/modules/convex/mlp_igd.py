# coding=utf-8
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
@file mlp_igd.py_in

@brief Multilayer perceptron using IGD: Driver functions

@namespace mlp_igd
"""
import math
import plpy

from convex.utils_regularization import __utils_ind_var_scales
from convex.utils_regularization import __utils_ind_var_scales_grouping
from convex.utils_regularization import __utils_normalize_data
from convex.utils_regularization import __utils_normalize_data_grouping

from utilities.in_mem_group_control import GroupIterationController
from utilities.utilities import _array_to_string
from utilities.utilities import _assert
from utilities.utilities import _assert_equal
from utilities.utilities import _string_to_array_with_quotes
from utilities.utilities import add_postfix
from utilities.utilities import extract_keyvalue_params
from utilities.utilities import py_list_to_sql_string
from utilities.utilities import strip_end_quotes, split_quoted_delimited_str
from utilities.utilities import unique_string
from utilities.utilities import get_grouping_col_str
from utilities.validate_args import _tbl_dimension_rownum
from utilities.validate_args import array_col_dimension
from utilities.validate_args import array_col_has_same_dimension
from utilities.validate_args import cols_in_tbl_valid
from utilities.validate_args import get_expr_type
from utilities.validate_args import input_tbl_valid
from utilities.validate_args import is_var_valid
from utilities.validate_args import output_tbl_valid
from utilities.validate_args import table_exists

from utilities.validate_args import get_cols_and_types

def mlp(schema_madlib, source_table, output_table, independent_varname,
        dependent_varname, hidden_layer_sizes, optimizer_param_str, activation,
        is_classification, weights, warm_start, verbose=False, grouping_col=""):
    """
    Args:
        @param schema_madlib
        @param source_table
        @param output_table
        @param independent_varname
        @param dependent_varname
        @param hidden_layer_sizes
        @param optimizer_param_str

    Returns:
        None
    """
    warm_start = bool(warm_start)
    optimizer_params = _get_optimizer_params(optimizer_param_str or "")
    summary_table = add_postfix(output_table, "_summary")
    standardization_table = add_postfix(output_table, "_standardization")
    weights = '1' if not weights or not weights.strip() else weights.strip()
    hidden_layer_sizes = hidden_layer_sizes or []

    grouping_col = grouping_col or ""
    activation = _get_activation_function_name(activation)
    learning_rate_policy = _get_learning_rate_policy_name(
        optimizer_params["learning_rate_policy"])
    activation_index = _get_activation_index(activation)

    _validate_args(source_table, output_table, summary_table,
                   standardization_table, independent_varname,
                   dependent_varname, hidden_layer_sizes, optimizer_params,
                   is_classification, weights, warm_start, activation,
                   grouping_col)

    reserved_cols = ['coeff', 'loss', 'n_iterations']
    grouping_str, grouping_col = get_grouping_col_str(schema_madlib, 'MLP',
                                                      reserved_cols,
                                                      source_table,
                                                      grouping_col)
    current_iteration = 1
    prev_state = None
    tolerance = optimizer_params["tolerance"]
    n_iterations = optimizer_params["n_iterations"]
    step_size_init = optimizer_params["learning_rate_init"]
    iterations_per_step = optimizer_params["iterations_per_step"]
    power = optimizer_params["power"]
    gamma = optimizer_params["gamma"]
    step_size = step_size_init
    n_tries = optimizer_params["n_tries"]
    # lambda is a reserved word in python
    lmbda = optimizer_params["lambda"]
    iterations_per_step = optimizer_params["iterations_per_step"]
    num_input_nodes = array_col_dimension(source_table,
                                          independent_varname)
    num_output_nodes = 0
    classes = []
    dependent_type = get_expr_type(dependent_varname, source_table)
    original_dependent_varname = dependent_varname

    x_mean_table = unique_string(desp='x_mean_table')
    dimension, n_tuples = _tbl_dimension_rownum(schema_madlib, source_table,
                                                independent_varname)

    tbl_data_scaled = unique_string(desp="tbl_data_scaled")
    col_ind_var_norm_new = unique_string(desp="ind_var_norm")
    col_dep_var_norm_new = unique_string(desp="dep_var_norm")
    # Standardize the data, and create a standardized version of the
    # source_table in tbl_data_scaled. Use this standardized table for IGD.
    normalize_data(locals())
    if is_classification:
        dependent_variable_sql = """
            SELECT DISTINCT {dependent_varname}
            FROM {source_table}
        """.format(dependent_varname=dependent_varname,
                   source_table=source_table)
        labels = plpy.execute(dependent_variable_sql)
        one_hot_dependent_varname = 'ARRAY['
        num_output_nodes = len(labels)
        for label_obj in labels:
            label = _format_label(label_obj[dependent_varname])
            classes.append(label)
        classes.sort()
        for c in classes:
            one_hot_dependent_varname += col_dep_var_norm_new + \
                "=" + str(c) + ","
        # Remove the last comma
        one_hot_dependent_varname = one_hot_dependent_varname[:-1]
        one_hot_dependent_varname += ']::integer[]'
        dependent_varname = one_hot_dependent_varname
    else:
        if "[]" not in dependent_type:
            dependent_varname = "ARRAY[" + col_dep_var_norm_new + "]"
        num_output_nodes = array_col_dimension(tbl_data_scaled,
                                               dependent_varname)
    # Need layers sizes before validating for warm_start
    layer_sizes = [num_input_nodes] + \
        hidden_layer_sizes + [num_output_nodes]
    col_grp_key = unique_string(desp='col_grp_key')
    if warm_start:
        coeff = _validate_warm_start(output_table, summary_table,
                                     standardization_table, independent_varname,
                                     original_dependent_varname, layer_sizes,
                                     optimizer_params, is_classification,
                                     weights, warm_start, activation)
        if grouping_col:
            grouping_col_list = split_quoted_delimited_str(grouping_col)
            join_condition = ' AND '.join(
                ['p.{col}={col}'.format(**locals())
                    for col in grouping_col_list])
            join_condition += ' AND '
            join_condition += "array_to_string(ARRAY[{0}], ',')={1}".format(
                                                    grouping_str, col_grp_key)
            start_coeff = """SELECT coeff FROM {output_table} as p
                WHERE {join_condition}
            """.format(**locals())
        else:
            start_coeff = py_list_to_sql_string(coeff,
                                                array_type="DOUBLE PRECISION")

    if grouping_col:
        group_by_clause = "GROUP BY {0}, {1}".format(grouping_col, col_grp_key)
        grouping_str_comma = grouping_col + ","
        using_clause = "USING ({0})".format(col_grp_key)
    else:
        group_by_clause, grouping_str_comma, using_clause = "", "", "ON TRUE"

    # local variables
    it_args = {
        "schema_madlib": schema_madlib,
        "independent_varname": independent_varname,
        "dependent_varname": dependent_varname,
        "prev_state": None,
        "layer_sizes": py_list_to_sql_string(
            layer_sizes, array_type="DOUBLE PRECISION"),
        "step_size": step_size,
        "source_table": source_table,
        "output_table": output_table,
        "activation": activation_index,
        "is_classification": int(is_classification),
        "weights": weights,
        "warm_start": warm_start,
        "n_tuples": n_tuples,
        "n_iterations": n_iterations,
        "tolerance": tolerance,
        "lmbda": lmbda,
        "grouping_col": grouping_col,
        "grouping_str": grouping_str,
        "x_mean_table": x_mean_table
    }
    # variables to be used by GroupIterationController
    it_args.update({
        'rel_args': unique_string(desp='rel_args'),
        'rel_state': unique_string(desp='rel_state'),
        'col_grp_iteration': unique_string(desp='col_grp_iteration'),
        'col_grp_state': unique_string(desp='col_grp_state'),
        'col_grp_key': col_grp_key,
        'col_n_tuples': unique_string(desp='col_n_tuples'),
        'state_type': "double precision[]",
        'rel_source': tbl_data_scaled,
        'col_ind_var': col_ind_var_norm_new,
        'col_dep_var': col_dep_var_norm_new,
        'state_size': -1
    })
    # variables used in constructing output tables
    it_args.update({
        'group_by_clause': group_by_clause,
        'using_clause': using_clause,
        'grouping_str_comma': grouping_str_comma
    })

    first_try = True
    temp_output_table = unique_string(desp='temp_output_table')
    for _ in range(n_tries):
        if not warm_start:
            coeff = []
            for i in range(len(layer_sizes) - 1):
                fan_in = layer_sizes[i]
                fan_out = layer_sizes[i + 1]
                # Initalize according to Glorot and Bengio (2010)
                # See design doc for more info
                span = math.sqrt(6.0 / (fan_in + fan_out))
                dim = (layer_sizes[i] + 1) * layer_sizes[i + 1]
                rand = plpy.execute("""SELECT array_agg({span}*2*(random()-0.5))
                                       AS random
                                       FROM generate_series(0,{dim})
                        """.format(span=span, dim=dim))[0]["random"]
                coeff += rand
            start_coeff = py_list_to_sql_string(
                coeff, "double precision")
        it_args['start_coeff'] = start_coeff
        iterationCtrl = GroupIterationController(it_args)
        with iterationCtrl as it:
            it.iteration = 0
            while True:
                zero_indexed_iteration = current_iteration - 1
                if learning_rate_policy == "exp":
                    step_size = step_size_init * gamma**zero_indexed_iteration
                elif learning_rate_policy == "inv":
                    step_size = step_size_init * (current_iteration)**(-power)
                elif learning_rate_policy == "step":
                    step_size = step_size_init * gamma**(
                        math.floor(zero_indexed_iteration / iterations_per_step))
                it.kwargs['step_size'] = step_size

                it.update("""
                {schema_madlib}.mlp_igd_step(
                    ({col_ind_var})::DOUBLE PRECISION[],
                    ({dependent_varname})::DOUBLE PRECISION[],
                    {rel_state}.{col_grp_state},
                    {layer_sizes},
                    ({step_size})::FLOAT8,
                    {activation},
                    {is_classification},
                    ({weights})::DOUBLE PRECISION,
                    {warm_start},
                    ({start_coeff})::DOUBLE PRECISION[],
                    {lmbda}
                )
                """)
                if it_args['state_size'] == -1:
                    it_args['state_size'] = it.get_state_size()

                if it.test("""
                    {iteration} >= {n_iterations}
                        OR
                        abs(_state_previous[{state_size}]
                        - _state_current[{state_size}]) < {tolerance}
                    """):
                    break
                if verbose and 1 < it.iteration <= n_iterations:
                    # Get loss value from the state.
                    res = it.get_param_value_per_group("""
                            _state_current[array_length(_state_current,1)] AS loss
                          """)
                    # Create a list of grouping values if grouping_cols was
                    # used, it will be an empty list if there was not grouping.
                    groups = [t[col_grp_key] for t in res if t[col_grp_key]]
                    losses = [t['loss'] for t in res]
                    loss = zip(groups, losses) if len(groups)==len(losses) \
                                               else losses
                    plpy.info("Iteration: " + str(it.iteration) + ", Loss: <" + \
                              ', '.join([str(l) for l in loss]) + ">")
            it.final()
        _update_temp_model_table(it_args, it.iteration, temp_output_table,
                                 first_try)
        first_try = False
    layer_sizes_str = py_list_to_sql_string(
        layer_sizes, array_type="integer")
    classes_str = py_list_to_sql_string(
        [strip_end_quotes(cl, "'") for cl in classes],
        array_type=dependent_type)
    _create_summary_table(locals())
    _create_standardization_table(standardization_table, x_mean_table,
                                  warm_start)
    _create_output_table(output_table, temp_output_table, grouping_col,
                         warm_start)
    plpy.execute("DROP TABLE IF EXISTS {0},{1}".format(temp_output_table,
                                                        tbl_data_scaled))
    return None


def normalize_data(args):
    """
        Create a new temp table (tbl_data_scaled) with the standardized version
        of the independent variable column (independent_varname) in the input
        data table (source_table).
    """
    # We don't have to standardize the dependent variable.
    y_decenter = False
    # For MLP we need to change std. dev value of 0 to 1. Set the following
    # flag to True to invoke the corresponding utils_regularization method.
    set_zero_std_to_one = True
    if args["grouping_col"]:
        # When grouping_col is defined, we must find an array containing
        # the mean and std of every dimension in the independent variable (x)
        # specific to groups. Store these results in temp tables x_mean_table
        # __utils_normalize_data_grouping reads the various means and stds
        # from the tables.
        __utils_ind_var_scales_grouping(args["source_table"],
                                        args["independent_varname"],
                                        args["dimension"], args["schema_madlib"],
                                        args["grouping_col"],
                                        args["x_mean_table"],
                                        set_zero_std_to_one)
        __utils_normalize_data_grouping(y_decenter,
                                       tbl_data=args["source_table"],
                                       col_ind_var=args["independent_varname"],
                                       col_dep_var=args["dependent_varname"],
                                       tbl_data_scaled=args["tbl_data_scaled"],
                                       col_ind_var_norm_new=args["col_ind_var_norm_new"],
                                       col_dep_var_norm_new=args["col_dep_var_norm_new"],
                                       schema_madlib=args["schema_madlib"],
                                       x_mean_table=args["x_mean_table"],
                                       y_mean_table='',
                                       grouping_col=args["grouping_col"])
    else:
        # When no grouping_col is defined, the mean and std for 'x'
        # can be defined using strings, stored in x_mean_str, x_std_str.
        # We don't need a table like how we needed for grouping.
        x_scaled_vals = __utils_ind_var_scales(args["source_table"],
                                               args["independent_varname"],
                                               args["dimension"],
                                               args["schema_madlib"],
                                               args["x_mean_table"],
                                               set_zero_std_to_one)
        x_mean_str = _array_to_string(x_scaled_vals["mean"])
        x_std_str = _array_to_string(x_scaled_vals["std"])
        __utils_normalize_data(y_decenter,
                               tbl_data=args["source_table"],
                               col_ind_var=args["independent_varname"],
                               col_dep_var=args["dependent_varname"],
                               tbl_data_scaled=args["tbl_data_scaled"],
                               col_ind_var_norm_new=args["col_ind_var_norm_new"],
                               col_dep_var_norm_new=args["col_dep_var_norm_new"],
                               schema_madlib=args["schema_madlib"],
                               x_mean_str=x_mean_str,
                               x_std_str=x_std_str,
                               y_mean='',
                               y_std='',
                               grouping_col=args["grouping_col"])

    return None
# ------------------------------------------------------------------------

def _create_standardization_table(standardization_table, x_mean_table, warm_start):
    if warm_start:
        plpy.execute("DROP TABLE IF EXISTS {0}".format(standardization_table))
    standarization_table_creation_query = """
        CREATE TABLE {standardization_table} AS (
        SELECT * FROM {x_mean_table}
        )
    """.format(**locals())
    plpy.execute(standarization_table_creation_query)
    plpy.execute("DROP TABLE IF EXISTS {0}".format(x_mean_table))


def _create_summary_table(args):
    grouping_text = "NULL" if not args['grouping_col'] else args['grouping_col']
    args.update(locals())
    if args['warm_start']:
        plpy.execute("DROP TABLE IF EXISTS {0}".format(args['summary_table']))

    summary_table_creation_query = """
        CREATE TABLE {summary_table}(
            source_table TEXT,
            independent_varname TEXT,
            dependent_varname TEXT,
            tolerance FLOAT,
            learning_rate_init FLOAT,
            learning_rate_policy TEXT,
            n_iterations INTEGER,
            n_tries INTEGER,
            layer_sizes INTEGER[],
            activation TEXT,
            is_classification BOOLEAN,
            classes {dependent_type}[],
            weights VARCHAR,
            grouping_col VARCHAR
        )""".format(**args)
    summary_table_update_query = """
        INSERT INTO {summary_table} VALUES(
            '{source_table}',
            '{independent_varname}',
            '{original_dependent_varname}',
            {tolerance},
            {step_size_init},
            '{learning_rate_policy}',
            {n_iterations},
            {n_tries},
            {layer_sizes_str},
            '{activation}',
            {is_classification},
            {classes_str},
            '{weights}',
            '{grouping_text}'
        )""".format(**args)
    plpy.execute(summary_table_creation_query)
    plpy.execute(summary_table_update_query)


def _create_output_table(output_table, temp_output_table,
                         grouping_col, warm_start):
    grouping_col_comma = ''
    partition_by = ''
    if grouping_col:
        grouping_col_comma = grouping_col + ","
        partition_by = " PARTITION BY {0} ".format(grouping_col)
    if warm_start:
        plpy.execute("DROP TABLE IF EXISTS {0}".format(output_table))
    build_output_query = """
        CREATE TABLE {output_table} AS
        SELECT {grouping_col_comma} coeff, loss, num_iterations FROM
        (SELECT {temp_output_table}.*, row_number()
        OVER ({partition_by} ORDER BY loss)
        AS rank FROM {temp_output_table}) x WHERE x.rank=1;
    """.format(**locals())
    plpy.execute(build_output_query)


def _update_temp_model_table(args, iteration, temp_output_table, first_try):
    insert_or_create_str = "INSERT INTO {0}"
    if first_try:
        insert_or_create_str = "CREATE TEMP TABLE {0} as"
    insert_or_create_str = insert_or_create_str.format(temp_output_table)
    join_clause = ''
    if args['grouping_col']:
        join_clause = """
                JOIN
                (
                    SELECT
                    {grouping_str_comma}
                    array_to_string(ARRAY[{grouping_str}],
                                    ','
                                   ) AS {col_grp_key}
                    FROM {source_table}
                    {group_by_clause}
                ) grouping_q
                {using_clause}
            """.format(**args)
    model_table_query = """
    {insert_or_create_str}
        SELECT
            {grouping_str_comma}
            (result).coeff as coeff,
            (result).loss  as loss,
            {iteration} as num_iterations
        FROM (
            SELECT
                {schema_madlib}.internal_mlp_igd_result(
                    {col_grp_state}
                ) AS result,
                {col_grp_key}
                FROM {rel_state}
                WHERE {col_grp_iteration} = {iteration}
        ) rel_state_subq
        {join_clause}
    """.format(insert_or_create_str=insert_or_create_str,
               iteration=iteration, join_clause=join_clause, **args)
    plpy.execute(model_table_query)


def _get_optimizer_params(param_str):
    params_defaults = {
        "learning_rate_init": (0.001, float),
        "n_iterations": (100, int),
        "n_tries": (1, int),
        "tolerance": (0.001, float),
        "learning_rate_policy": ("constant", str),
        "gamma": (0.1, float),
        "iterations_per_step": (100, int),
        "power": (0.5, float),
        "lambda": (0, float)
    }
    param_defaults = dict([(k, v[0]) for k, v in params_defaults.items()])
    param_types = dict([(k, v[1]) for k, v in params_defaults.items()])

    if not param_str:
        return param_defaults

    name_value = extract_keyvalue_params(
        param_str, param_types, param_defaults, ignore_invalid=False)
    return name_value


def _validate_args_classification(source_table, dependent_varname):
    expr_type = get_expr_type(dependent_varname, source_table)
    int_types = ['integer', 'smallint', 'bigint']
    text_types = ['text', 'varchar', 'character varying', 'char', 'character']
    boolean_types = ['boolean']
    _assert("[]" in expr_type
            or expr_type in int_types + text_types + boolean_types,
            "Dependent variable column should refer to an "
            "integer, boolean, text, varchar, or character type.")


def _validate_args_regression(source_table, dependent_varname):
    expr_type = get_expr_type(dependent_varname, source_table)
    int_types = ['integer', 'smallint', 'bigint']
    float_types = ['double precision', 'real']
    _assert(
        "[]" in expr_type or expr_type in int_types + float_types,
        "Dependent variable column should refer to an array or numeric type")
    if "[]" in expr_type:
        _assert(
            array_col_has_same_dimension(source_table, dependent_varname),
            "Dependent variable column should refer to arrays of the same length"
        )

def _validate_standardization_table(standardization_table, glist=[]):
    input_tbl_valid(standardization_table, 'MLP')
    cols_in_tbl_valid(standardization_table, glist + ['mean', 'std'], 'MLP')

def _validate_summary_table(summary_table):
    input_tbl_valid(summary_table, 'MLP')
    cols_in_tbl_valid(summary_table, [
        'dependent_varname', 'independent_varname', 'activation',
        'tolerance', 'learning_rate_init', 'n_iterations', 'n_tries',
        'classes', 'layer_sizes', 'source_table'
    ], 'MLP')


def _validate_warm_start(output_table, summary_table, standardization_table,
                         independent_varname, dependent_varname, layer_sizes,
                         optimizer_params, is_classification, weights,
                         warm_start, activation):
    _assert(table_exists(output_table),
            "MLP error: Warm start failed due to missing model table: " + output_table)
    _assert(table_exists(summary_table),
            "MLP error: Warm start failed due to missing summary table: " + summary_table)
    _assert(table_exists(standardization_table),
            "MLP error: Warm start failed due to missing standardization table: " + standardization_table)

    _assert(optimizer_params["n_tries"] == 1,
            "MLP error: warm_start is only compatible for n_tries = 1")

    summary = plpy.execute("SELECT * FROM {0}".format(summary_table))[0]
    params = [
        "independent_varname", "dependent_varname", "layer_sizes",
        "is_classification", "weights", "activation"
    ]
    for param in params:
        _assert_equal(eval(param), summary[param],
                      "MLP error: warm start failed due to different parameter value: " +
                      param)
    output = plpy.execute("SELECT * FROM {0}".format(output_table))
    num_coeffs = sum(
        map(lambda i: (layer_sizes[i] + 1) * (layer_sizes[i + 1]),
            range(len(layer_sizes) - 1)))
    for row in output:
        coeff = row['coeff']
        _assert_equal(num_coeffs,
                      len(coeff),
                      "MLP error: Warm start failed to invalid output_table: " +
                      output_table + ". Invalid number of coefficients in model.")
    return coeff


def _validate_args(source_table, output_table, summary_table,
                   standardization_table, independent_varname,
                   dependent_varname, hidden_layer_sizes, optimizer_params,
                   is_classification, weights, warm_start, activation,
                   grouping_col):
    input_tbl_valid(source_table, "MLP")
    if not warm_start:
        output_tbl_valid(output_table, "MLP")
        output_tbl_valid(summary_table, "MLP")
        output_tbl_valid(standardization_table, "MLP")

    _assert(
        is_var_valid(source_table, independent_varname),
        "MLP error: invalid independent_varname "
        "('{independent_varname}') for source_table "
        "({source_table})!".format(
            independent_varname=independent_varname,
            source_table=source_table))

    _assert(
        is_var_valid(source_table, dependent_varname),
        "MLP error: invalid dependent_varname "
        "('{dependent_varname}') for source_table "
        "({source_table})!".format(
            dependent_varname=dependent_varname, source_table=source_table))
    _assert(
        isinstance(hidden_layer_sizes, list),
        "hidden_layer_sizes must be an array of integers")
    # TODO put this check earlier
    _assert(
        all(isinstance(value, int) for value in hidden_layer_sizes),
        "MLP error: Hidden layers sizes must be integers")
    _assert(
        all(value >= 0 for value in hidden_layer_sizes),
        "MLP error: Hidden layers sizes must be greater than 0.")
    _assert(optimizer_params["lambda"] >= 0,
            "MLP error: lambda should be greater than or equal to 0.")
    _assert(optimizer_params["tolerance"] >= 0,
            "MLP error: tolerance should be greater than or equal to 0.")
    _assert(optimizer_params["n_tries"] >= 1,
            "MLP error: n_tries should be greater than or equal to 1")
    _assert(
        optimizer_params["n_iterations"] >= 1,
        "MLP error: n_iterations should be greater than or equal to 1")
    _assert(optimizer_params["power"] > 0,
            "MLP error: power should be greater than 0.")
    _assert(0 < optimizer_params["gamma"] <= 1,
            "MLP error: gamma should be between 0 and 1.")
    _assert(optimizer_params["iterations_per_step"] > 0,
            "MLP error: iterations_per_step should be greater than 0.")
    _assert(optimizer_params["learning_rate_init"] > 0,
            "MLP error: learning_rate_init should be greater than 0.")
    _assert("[]" in get_expr_type(independent_varname, source_table),
            "Independent variable column should refer to an array")
    _assert(
        array_col_has_same_dimension(source_table, independent_varname),
        "Independent variable column should refer to arrays of the same length"
    )

    int_types = ['integer', 'smallint', 'bigint']
    float_types = ['double precision', 'real']
    _assert(
        get_expr_type(weights, source_table) in int_types + float_types,
        "MLP error: Weights should be a numeric type")

    if grouping_col:
        cols_in_tbl_valid(source_table,
                          _string_to_array_with_quotes(grouping_col),
                          'MLP')
    if is_classification:
        _validate_args_classification(source_table, dependent_varname)
    else:
        _validate_args_regression(source_table, dependent_varname)


def _get_learning_rate_policy_name(learning_rate_policy):
    if not learning_rate_policy:
        learning_rate_policy = 'constant'
    else:
        supported_learning_rate_policies = ['constant', 'exp', 'inv', 'step']
        try:
            learning_rate_policy = next(
                x for x in supported_learning_rate_policies
                if x.startswith(learning_rate_policy))
        except StopIteration:
            plpy.error(
                "MLP Error: Invalid learning rate policy: "
                "{0}. Supported learning rate policies are ({1})".format(
                    learning_rate_policy,
                    ','.join(sorted(supported_learning_rate_policies))))
    return learning_rate_policy


def _get_activation_function_name(activation):
    if not activation:
        activation = 'sigmoid'
    else:
        supported_activation_function = ['sigmoid', 'tanh', 'relu']
        try:
            activation = next(
                x for x in supported_activation_function
                if x.startswith(activation))
        except StopIteration:
            plpy.error("MLP Error: Invalid activation function: "
                       "{0}. Supported activation functions are ({1})".format(
                           activation,
                           ','.join(sorted(supported_activation_function))))
    return activation


def _get_activation_index(activation_name):
    table = {"relu": 0, "sigmoid": 1, "tanh": 2}
    return table[activation_name]


def _format_label(label):
    if isinstance(label, str):
        return "'" + label + "'"
    return label


def mlp_predict(schema_madlib,
                model_table,
                data_table,
                id_col_name,
                output_table,
                pred_type='response',
                **kwargs):
    """ Score new observations using a trained neural network

    @param schema_madlib Name of the schema where MADlib is installed
    @param model_table Name of learned model
    @param data_table Name of table/view containing the data
                          points to be scored
    @param id_col_name Name of column in source_table containing
                       (integer) identifier for data point
    @param output_table Name of table to store the results
    @param pred_type: str, The type of output required:
                    'response' gives the actual response values,
                    'prob' gives the probability of the classes in a
                  For regression, only type='response' is defined.
    """
    input_tbl_valid(model_table, 'MLP')
    cols_in_tbl_valid(model_table, ['coeff'], 'MLP')
    summary_table = add_postfix(model_table, "_summary")
    standardization_table = add_postfix(model_table, "_standardization")
    _validate_summary_table(summary_table)

    summary = plpy.execute("SELECT * FROM {0}".format(summary_table))[0]
    dependent_varname = summary['dependent_varname']
    independent_varname = summary['independent_varname']
    source_table = summary['source_table']
    activation = _get_activation_index(summary['activation'])
    layer_sizes = py_list_to_sql_string(
        summary['layer_sizes'], array_type="DOUBLE PRECISION")
    is_classification = int(summary["is_classification"])
    is_response = int(pred_type == 'response')
    grouping_col = '' if summary['grouping_col']=='NULL' \
                    else summary['grouping_col']

    pred_name = ('"prob_{0}"' if pred_type == "prob" else
                '"estimated_{0}"').format(
                    dependent_varname.replace('"', '').strip())

    input_tbl_valid(data_table, 'MLP')

    _assert(
        is_var_valid(data_table, independent_varname),
        "MLP Error: independent_varname ('{0}') is invalid for data_table ({1})".
        format(independent_varname, data_table))
    _assert(id_col_name is not None, "MLP Error: id_col_name is NULL")
    _assert(
        is_var_valid(data_table, id_col_name),
        "MLP Error: id_col_name ('{0}') is invalid for {1}".format(
            id_col_name, data_table))
    output_tbl_valid(output_table, 'MLP')

    header = "CREATE TABLE " + output_table + " AS "
    select_grouping_col = ""
    group_by_predict_str = ""
    grouping_col_comma = ""
    join_str = ''
    grouping_col_list = split_quoted_delimited_str(grouping_col)
    _validate_standardization_table(standardization_table, grouping_col_list)
    if grouping_col:
        join_str = """JOIN {model_table}
            USING ({grouping_col})
            JOIN {standardization_table}
            USING ({grouping_col})
        """.format(**locals())
        group_by = ', '.join(['{0}.{1}'.format(data_table, col)
                              for col in grouping_col_list])
        group_by_predict_str = "ORDER BY {0}, {1}.{2}".format(
                                group_by, data_table, id_col_name)
        select_grouping_col = ','.join(['q.{0}'.format(col)
                                        for col in grouping_col_list]) + ','
        grouping_col_comma = grouping_col+","

        coeff_column = "{model_table}.coeff::DOUBLE PRECISION[]".format(**locals())
        mean_col = "{standardization_table}.mean".format(**locals())
        std_col = "{standardization_table}.std".format(**locals())
    else:
        # if not grouping, then directly read out the coeff, mean
        # and std values from the model and standardization tables.
        standardization = plpy.execute(
            "SELECT * FROM {0}".format(standardization_table))[0]
        coeff = py_list_to_sql_string(plpy.execute(
            "SELECT * FROM {0}".format(model_table))[0]["coeff"])
        x_means = py_list_to_sql_string(
            standardization["mean"], array_type="DOUBLE PRECISION")
        x_stds = py_list_to_sql_string(
            standardization["std"], array_type="DOUBLE PRECISION")

        coeff_column = "{coeff}".format(**locals())
        mean_col = "{x_means}".format(**locals())
        std_col = "{x_stds}".format(**locals())

    predict_uda_query = """{schema_madlib}.internal_predict_mlp(
            {coeff_column},
            {independent_varname}::DOUBLE PRECISION[],
            {is_classification},
            {activation},
            {layer_sizes},
            {is_response},
            {mean_col},
            {std_col}
            )
        """.format(**locals())
    if not is_classification:
        dependent_type = get_expr_type(dependent_varname, source_table)
        unnest_if_not_array = ""
        # Return the same type as the user provided.  Internally we always
        # use an array, but if they provided a scaler, unnest it for
        # the user
        if "[]" not in dependent_type:
            unnest_if_not_array = "UNNEST"
        sql = header + """
                SELECT {grouping_col_comma}
                       {id_col_name},
                       {unnest_if_not_array}({predict_uda_query}) AS {pred_name}
                FROM {data_table}
                {join_str}
                {group_by_predict_str}
            """
    else:
        summary_query = """
            SELECT classes FROM {0}
        """.format(summary_table)
        classes = plpy.execute(summary_query)[0]['classes']
        if pred_type == "response":
            classes_with_index_table = unique_string()
            classes_table = unique_string()
            sql = header + """
                    SELECT {select_grouping_col}
                           q.{id_col_name},
                           (ARRAY{classes})[pred_idx[1]+1] as {pred_name}
                    FROM (
                        SELECT {grouping_col_comma}
                            {id_col_name},
                            {predict_uda_query} AS pred_idx
                        FROM {data_table}
                        {join_str}
                        {group_by_predict_str}
                    ) q
                """
        else:
            intermediate_col = unique_string()
            score_format = ',\n'.join([
                'CAST({interim}[{j}] as DOUBLE PRECISION) as "estimated_prob_{c_str}"'.
                format(j=i + 1, c_str=str(c).strip(' "'),
                       interim=intermediate_col)
                for i, c in enumerate(classes)])
            sql = header + """
                    SELECT {select_grouping_col}
                        {id_col_name},
                        {score_format}
                    FROM (
                        SELECT {grouping_col_comma}
                               {id_col_name},
                               {predict_uda_query}::TEXT[] AS {intermediate_col}
                        FROM {data_table}
                        {join_str}
                        {group_by_predict_str}
                    ) q
                """
    sql = sql.format(**locals())
    plpy.execute(sql)


def mlp_help(schema_madlib, message, is_classification):
    method = 'mlp_classification' if is_classification else 'mlp_regression'
    int_types = ['integer', 'smallint', 'bigint']
    text_types = ['text', 'varchar', 'character varying', 'char', 'character']
    boolean_types = ['boolean']
    supported_types = " " * 33 + ", ".join(text_types) + "\n" +\
        " " * 33 + ", ".join(int_types + boolean_types)
    label_description_classification = "Name of a column which specifies label.\n" +\
        " " * 33 + "Supported types are:\n" + supported_types
    label_description_regression = "Dependent variable. May be an array for multiple\n" +\
        " " * 33 + "regression or the name of a column which is any\n" + " " * 33 +\
        "numeric type for single regression"
    label_description = label_description_classification if is_classification\
        else label_description_regression
    args = dict(schema_madlib=schema_madlib, method=method,
                label_description=label_description)

    summary = """
    ----------------------------------------------------------------
                            SUMMARY
    ----------------------------------------------------------------
    Multilayer Perceptron (MLP) is a model for regression and
    classification

    Also called "vanilla neural networks", they consist of several
    fully connected hidden layers with non-linear activation
    functions.

    For more details on function usage:
        SELECT {schema_madlib}.{method}('usage')

    For a small example on using the function:
        SELECT {schema_madlib}.{method}('example')""".format(**args)

    usage = """
    ---------------------------------------------------------------------------
                                    USAGE
    ---------------------------------------------------------------------------
    SELECT {schema_madlib}.{method}(
        source_table,         -- TEXT. name of input table
        output_table,         -- TEXT. name of output model table
        independent_varname,  -- TEXT. name of independent variable
        dependent_varname,    -- TEXT. {label_description}
        hidden_layer_sizes,   -- INTEGER[]. Array of integers indicating the
                                 number of hidden units per layer.
                                 Length equal to the number of hidden layers.
        optimizer_params,     -- TEXT. optional, default NULL
                                 parameters for optimization in
                                 a comma-separated string of key-value pairs.
                                 To find out more:
                      SELECT {schema_madlib}.{method}('optimizer_params')

        activation            -- TEXT. optional, default: 'sigmoid'.
                                 supported activations: 'relu', 'sigmoid',
                                 and 'tanh'

        weights               -- TEXT. optional, default: NULL.
                                 Weights for input rows. Column name which
                                 specifies the weight for each input row.
                                 This weight will be incorporated into the
                                 update during SGD, and will not be used
                                 for loss calculations. If not specified,
                                 weight for each row will default to 1.
                                 Column should be a numeric type.

        warm_start            -- BOOLEAN. optional, default: FALSE.
                                 Initalize weights with the coefficients from
                                 the last call.  If true, weights will
                                 be initialized from output_table. Note that
                                 all parameters other than optimizer_params,
                                 and verbose must remain constant between calls
                                 to warm_start.

        verbose               -- BOOLEAN. optional, default: FALSE
                                 Provides verbose output of the results of
                                 training.

        grouping_col          -- TEXT. optional, default: NULL
                                 A single column or a list of comma-separated
                                 columns that divides the input data into discrete
                                 groups, resulting in one model per group. When
                                 this value is NULL, no grouping is used and a
                                 single model is generated for all data.
    );


    ---------------------------------------------------------------------------
                                    OUTPUT
    ---------------------------------------------------------------------------
    The model table produced by MLP contains the following columns:

    coeffs             -- Flat array containing the weights of the neural net
    loss               -- The total loss over the training data. Cross entropy
                       -- for classification and MSE for regression
    num_iterations     -- The total number of training iterations

    ---------------------------------------------------------------------------
    The algorithm also creates a summary table named <output_table>_summary
    that has the following columns:

    source_table         -- The source table.
    independent_varname  -- The independent variables.
    dependent_varname    -- The dependent variable.
    tolerance            -- The tolerance as given in optimizer_params.
    learning_rate_init   -- The initial learning rate as given in optimizer_params.
    learning_rate_policy -- The learning rate policy as given in optimizer_params.
    n_iterations         -- The number of iterations run.
    n_tries              -- The number of tries as given in optimizer_params.
    layer_sizes          -- The number of units in each layer including the input
                         -- and output layer.
    activation           -- The activation function.
    is_classification    -- True if the model was trained for classification, False
                         -- if it was trained for regression.
    classes              -- The classes which were trained against (empty for
                         -- regression).
    weights              -- The weight column used during training.
    grouping_col         -- NULL if no grouping_col was specified during training,
                         -- and a comma separated list of grouping column names if not.

    ---------------------------------------------------------------------------
    The algorithm also creates a standardization table that stores some meta data
    used during prediction, and is named <output_table>_standardization. It has
    the following columns:

    x_means           -- The mean for all input features (used for normalization).
    x_stds            -- The standard deviation for all input features (used for
                      -- normalization).
    grouping columns  -- If grouping_col is specified during training, a column for
                      -- each grouping column is created.

    """.format(**args)

    regression_example = """
    -- Create input table

    CREATE TABLE lin_housing (id serial, x float8[], zipcode int, y float8);
    COPY lin_housing (x, zipcode, y) FROM STDIN NULL '?' DELIMITER '|';
    {{1,0.00632,18.00,2.310,0,0.5380,6.5750,65.20,4.0900,1,296.0,15.30,396.90,4.98}}|94016|24.00
    {{1,0.02731,0.00,7.070,0,0.4690,6.4210,78.90,4.9671,2,242.0,17.80,396.90,9.14}}|94016|21.60
    {{1,0.02729,0.00,7.070,0,0.4690,7.1850,61.10,4.9671,2,242.0,17.80,392.83,4.03}}|94016|34.70
    {{1,0.03237,0.00,2.180,0,0.4580,6.9980,45.80,6.0622,3,222.0,18.70,394.63,2.94}}|94016|33.40
    {{1,0.06905,0.00,2.180,0,0.4580,7.1470,54.20,6.0622,3,222.0,18.70,396.90,5.33}}|94016|36.20
    {{1,0.02985,0.00,2.180,0,0.4580,6.4300,58.70,6.0622,3,222.0,18.70,394.12,5.21}}|94016|28.70
    {{1,0.08829,12.50,7.870,0,0.5240,6.0120,66.60,5.5605,5,311.0,15.20,395.60,12.43}}|94016|22.90
    {{1,0.14455,12.50,7.870,0,0.5240,6.1720,96.10,5.9505,5,311.0,15.20,396.90,19.15}}|94016|27.10
    {{1,0.21124,12.50,7.870,0,0.5240,5.6310,100.00,6.0821,5,311.0,15.20,386.63,29.93}}|94016|16.50
    {{1,0.17004,12.50,7.870,0,0.5240,6.0040,85.90,6.5921,5,311.0,15.20,386.71,17.10}}|94016|18.90
    {{1,0.22489,12.50,7.870,0,0.5240,6.3770,94.30,6.3467,5,311.0,15.20,392.52,20.45}}|94016|15.00
    {{1,0.11747,12.50,7.870,0,0.5240,6.0090,82.90,6.2267,5,311.0,15.20,396.90,13.27}}|20001|18.90
    {{1,0.09378,12.50,7.870,0,0.5240,5.8890,39.00,5.4509,5,311.0,15.20,390.50,15.71}}|20001|21.70
    {{1,0.62976,0.00,8.140,0,0.5380,5.9490,61.80,4.7075,4,307.0,21.00,396.90,8.26}}|20001|20.40
    {{1,0.63796,0.00,8.140,0,0.5380,6.0960,84.50,4.4619,4,307.0,21.00,380.02,10.26}}|20001|18.20
    {{1,0.62739,0.00,8.140,0,0.5380,5.8340,56.50,4.4986,4,307.0,21.00,395.62,8.47}}|20001|19.90
    {{1,1.05393,0.00,8.140,0,0.5380,5.9350,29.30,4.4986,4,307.0,21.00,386.85,6.58}}|20001| 23.10
    {{1,0.78420,0.00,8.140,0,0.5380,5.9900,81.70,4.2579,4,307.0,21.00,386.75,14.67}}|20001|17.50
    {{1,0.80271,0.00,8.140,0,0.5380,5.4560,36.60,3.7965,4,307.0,21.00,288.99,11.69}}|20001|20.20
    {{1,0.72580,0.00,8.140,0,0.5380,5.7270,69.50,3.7965,4,307.0,21.00,390.95,11.28}}|20001|18.20
    \.

    -- Generate a multilayer perception with a two hidden layers of 25 units
    -- each. Use the x column as the independent variables, and use the class
    -- column as the classification. Set the tolerance to 0 so that 500
    -- iterations will be run. Use a sigmoid activation function.
    -- The model will be written to mlp_regress_result.

    DROP TABLE IF EXISTS mlp_regress, mlp_regress_summary, mlp_regress_standardization;
    SELECT {schema_madlib}.{method}(
        'lin_housing',    -- Source table
        'mlp_regress',    -- Desination table
        'x',              -- Input features
        'y',              -- Dependent variable
        ARRAY[25,25],     -- Number of units per layer
        'learning_rate_init=0.001,
        n_iterations=500,
        lambda=0.001,
        tolerance=0',     -- Optimizer params
        'relu',           -- Activation function
        NULL,             -- Default weight (1)
        FALSE,            -- No warm start
        FALSE             -- Not verbose
    );
    SELECT * FROM mlp_regress;

    -- Use the n_tries optimizer param to learn the best of multiple models:
    DROP TABLE IF EXISTS mlp_regress, mlp_regress_summary, mlp_regress_standardization;
    SELECT {schema_madlib}.{method}(
        'lin_housing',    -- Source table
        'mlp_regress',    -- Desination table
        'x',              -- Input features
        'y',              -- Dependent variable
        ARRAY[25,25],     -- Number of units per layer
        'learning_rate_init=0.001,
        n_iterations=50,
        n_tries=3,
        lambda=0.001,
        tolerance=0',     -- Optimizer params, with n_tries
        'relu',           -- Activation function
        NULL,             -- Default weight (1)
        FALSE,            -- No warm start
        FALSE             -- Not verbose
    );
    SELECT * FROM mlp_regress;

    -- Use the warm start param to improve the model present in mlp_regress.
    -- Note that mlp_regress should not be dropped.
    SELECT {schema_madlib}.{method}(
        'lin_housing',    -- Source table
        'mlp_regress',    -- Desination table
        'x',              -- Input features
        'y',              -- Dependent variable
        ARRAY[25,25],     -- Number of units per layer
        'learning_rate_init=0.001,
        n_iterations=50,
        n_tries=3
        lambda=0.001,
        tolerance=0',
        'relu',           -- Activation function
        NULL,             -- Default weight (1)
        TRUE,             -- Warm start
        FALSE             -- Verbose
    );
    SELECT * FROM mlp_regress;

    -- Use the grouping feature to learn a different model for each zipcode:
    DROP TABLE IF EXISTS mlp_regress_group, mlp_regress_group_summary;
    DROP TABLE IF EXISTS mlp_regress_group_standardization;
    SELECT {schema_madlib}.{method}(
        'lin_housing',    -- Source table
        'mlp_regress_group',  -- Desination table
        'x',              -- Input features
        'y',              -- Dependent variable
        ARRAY[25,25],     -- Number of units per layer
        'learning_rate_init=0.001,
        n_iterations=50,
        lambda=0.001,
        tolerance=0',     -- Optimizer params, with n_tries
        'relu',           -- Activation function
        NULL,             -- Default weight (1)
        FALSE,            -- No warm start
        FALSE,            -- Not verbose
        'zipcode'         -- Grouping column
    );
    SELECT * FROM mlp_regress_group;

    -- n_tries and warm_start can be used with grouping too, similar to as
    -- shown above without grouping.

    """

    classification_example = """
    -- Create input table

    CREATE TABLE iris_data(
        id INTEGER,
        attributes NUMERIC[],
        class_text VARCHAR,
        class INTEGER,
        state VARCHAR
    );

    COPY iris_data (attributes, class_text, class, state) FROM STDIN NULL '?' DELIMITER '|';
    {{4.4,3.2,1.3,0.2}}|Iris_setosa|1|Alaska
    {{5.0,3.5,1.6,0.6}}|Iris_setosa|1|Alaska
    {{5.1,3.8,1.9,0.4}}|Iris_setosa|1|Alaska
    {{4.8,3.0,1.4,0.3}}|Iris_setosa|1|Alaska
    {{5.1,3.8,1.6,0.2}}|Iris_setosa|1|Alaska
    {{5.7,2.8,4.5,1.3}}|Iris_versicolor|2|Alaska
    {{6.3,3.3,4.7,1.6}}|Iris_versicolor|2|Alaska
    {{4.9,2.4,3.3,1.0}}|Iris_versicolor|2|Alaska
    {{6.6,2.9,4.6,1.3}}|Iris_versicolor|2|Alaska
    {{5.2,2.7,3.9,1.4}}|Iris_versicolor|2|Alaska
    {{5.0,2.0,3.5,1.0}}|Iris_versicolor|2|Alaska
    {{4.8,3.0,1.4,0.1}}|Iris_setosa|1|Tennessee
    {{4.3,3.0,1.1,0.1}}|Iris_setosa|1|Tennessee
    {{5.8,4.0,1.2,0.2}}|Iris_setosa|1|Tennessee
    {{5.7,4.4,1.5,0.4}}|Iris_setosa|1|Tennessee
    {{5.4,3.9,1.3,0.4}}|Iris_setosa|1|Tennessee
    {{6.0,2.9,4.5,1.5}}|Iris_versicolor|2|Tennessee
    {{5.7,2.6,3.5,1.0}}|Iris_versicolor|2|Tennessee
    {{5.5,2.4,3.8,1.1}}|Iris_versicolor|2|Tennessee
    {{5.5,2.4,3.7,1.0}}|Iris_versicolor|2|Tennessee
    {{5.8,2.7,3.9,1.2}}|Iris_versicolor|2|Tennessee
    {{6.0,2.7,5.1,1.6}}|Iris_versicolor|2|Tennessee
    \.


    -- Generate a multilayer perception with a single hidden layer of 5 units.
    -- Use the attributes column as the independent variables, and use the class
    -- column as the classification. Set the tolerance to 0 so that 500
    -- iterations will be run. Use a hyperbolic tangent activation function.
    -- The model will be written to mlp_model.

    DROP TABLE IF EXISTS mlp_model, mlp_model_summary, mlp_model_standardization;
    SELECT madlib.mlp_classification(
        'iris_data',      -- Source table
        'mlp_model',      -- Destination table
        'attributes',     -- Input features
        'class_text',     -- Label
        ARRAY[5],         -- Number of units per layer
        'learning_rate_init=0.003,
        n_iterations=500,
        tolerance=0',     -- Optimizer params
        'tanh',           -- Activation function
        NULL,             -- Default weight (1)
        FALSE,            -- No warm start
        FALSE             -- Not verbose
    );

    SELECT * FROM mlp_model;

    -- Use the n_tries optimizer param to learn the best of multiple models:
    DROP TABLE IF EXISTS mlp_model, mlp_model_summary, mlp_model_standardization;
    SELECT madlib.mlp_classification(
        'iris_data',      -- Source table
        'mlp_model',      -- Destination table
        'attributes',     -- Input features
        'class_text',     -- Label
        ARRAY[5],         -- Number of units per layer
        'learning_rate_init=0.003,
        n_iterations=500,
        n_tries=3,
        tolerance=0',     -- Optimizer params, with n_tries
        'tanh',           -- Activation function
        NULL,             -- Default weight (1)
        FALSE,            -- No warm start
        FALSE             -- Not verbose
    );

    -- Use the warm start param to improve the model present in mlp_model.
    -- Note that mlp_model should not be dropped.
    SELECT madlib.mlp_classification(
        'iris_data',      -- Source table
        'mlp_model',      -- Destination table
        'attributes',     -- Input features
        'class_text',     -- Label
        ARRAY[5],         -- Number of units per layer
        'learning_rate_init=0.003,
        n_iterations=500,
        tolerance=0',     -- Optimizer params
        'tanh',           -- Activation function
        NULL,             -- Default weight (1)
        FALSE,            -- Warm start
        FALSE             -- Not verbose
    );

    -- Use the grouping feature to learn a different model for each state:
    DROP TABLE IF EXISTS mlp_model_group, mlp_model_group_summary;
    DROP TABLE IF EXISTS mlp_model_group_standardization;
    SELECT madlib.mlp_classification(
        'iris_data',      -- Source table
        'mlp_model_group',-- Destination table
        'attributes',     -- Input features
        'class_text',     -- Label
        ARRAY[5],         -- Number of units per layer
        'learning_rate_init=0.003,
        n_iterations=500,
        tolerance=0',     -- Optimizer params
        'tanh',           -- Activation function
        NULL,             -- Default weight (1)
        FALSE,            -- No warm start
        FALSE,            -- Not verbose
        'state'           -- Grouping column
    );

    -- n_tries and warm_start can be used with grouping too, similar to as
    -- shown above without grouping.

    """.format(**args)
    example = classification_example if is_classification else regression_example
    optimizer_params = """
    ------------------------------------------------------------------------------------------------
                                               OPTIMIZER PARAMS
    ------------------------------------------------------------------------------------------------
    learning_rate_init DOUBLE PRECISION, -- Default: 0.001
                                            Initial learning rate
    learning_rate_policy VARCHAR,        -- Default: 'constant'
                                            One of 'constant','exp','inv','step'
                                            'constant': learning_rate =
                                            learning_rate_init
                                            'exp': learning_rate =
                                            learning_rate_init * gamma^(iter)
                                            'inv': learning_rate =
                                            learning_rate_init * (iter+1)^(-power)
                                            'step': learning_rate =
                                            learning_rate_init * gamma^(floor(iter/iterations_per_step))
                                            Where iter is the current iteration of SGD.
    gamma DOUBLE PRECISION,              -- Default: '0.1'
                                            Decay rate for learning rate.
                                            Valid for learning_rate_policy = 'exp', or 'step'
    power DOUBLE PRECISION,              -- Default: '0.5'
                                            Exponent for learning_rate_policy = 'inv'
    iterations_per_step INTEGER,             -- Default: '100'
                                            Number of iterations to run before decreasing the learning
                                            rate by a factor of gamma.  Valid for learning rate
                                            policy = 'step'
    n_iterations INTEGER,                -- Default: 100
                                            Number of iterations per try
    n_tries INTEGER,                     -- Default: 1
                                            Total number of training cycles,
                                            with random initializations to avoid
                                            local minima.
    tolerance DOUBLE PRECISION,          -- Default: 0.001
                                            If the distance in loss between
                                            two iterations is less than the
                                            tolerance training will stop, even if
                                            n_iterations has not been reached.
    """.format(**args)

    if not message:
        return summary
    elif message.lower() in ('usage', 'help', '?'):
        return usage
    elif message.lower() == 'example':
        return example
    elif message.lower() == 'optimizer_params':
        return optimizer_params
    return """
        No such option. Use "SELECT {schema_madlib}.{method}()" for help.
    """.format(**args)


def mlp_predict_help(schema_madlib, message):
    args = dict(schema_madlib=schema_madlib)

    summary = """
    ----------------------------------------------------------------
                            SUMMARY
    ----------------------------------------------------------------
    Multilayer Perceptron (MLP) is a model for regression and
    classification

    Also called "vanilla neural networks", they consist of several
    fully connected hidden layers with non-linear activation
    functions.

    For more details on function usage:
        SELECT {schema_madlib}.mlp_predict('usage')

    For a small example on using the function:
        SELECT {schema_madlib}.mlp_predict('example')""".format(**args)

    usage = """
    ---------------------------------------------------------------------------
                                    USAGE
    ---------------------------------------------------------------------------
    SELECT {schema_madlib}.mlp_predict(
        model_table,        -- name of model table
        data_table,         -- name of data table
        id_col_name,        -- id column for data table
        output_table,       -- name of output table
        pred_type           -- the type of output requested:
                            -- 'response' gives the actual prediction,
                            -- 'prob' gives the probability of each class.
                            -- for regression, only type='response' is defined.
    );


    ---------------------------------------------------------------------------
                                    OUTPUT
    ---------------------------------------------------------------------------
    The model table produced by mlp contains the following columns:

    id                      -- The provided id for the given input vector

    estimated_<COL_NAME>    -- (For pred_type='response') The estimated class
                               for classification or value for regression, where
                               <COL_NAME> is the name of the column to be
                               predicted from training data

    prob_<CLASS>            -- (For pred_type='prob' for classification) The
                               probability of a given class <CLASS> as given by
                               softmax. There will be one column for each class
                               in the training data.

    """.format(**args)

    example = """
    -- See {schema_madlib}.mlp_classification('example') for test
    -- and model tables

    -- Predict classes using
    SELECT {schema_madlib}.mlp_predict(
        'mlp_model',         -- Model table
        'iris_data',         -- Test data table
        'id',                -- Id column in test table
        'mlp_prediction',    -- Output table for predictions
        'response'           -- Output classes, not probabilities
    );
    SELECT * FROM mlp_prediction;

    WITH total_count AS (SELECT count(*) AS c FROM iris_data)
    SELECT count(*)/((SELECT c FROM total_count)::DOUBLE PRECISION)
    AS train_accuracy
    FROM
        (
            SELECT iris_data.class_text AS actual_label,
                mlp_prediction.estimated_class_text AS predicted_label
            FROM mlp_prediction
            INNER JOIN iris_data ON iris_data.id=mlp_prediction.id
        ) q
    WHERE q.actual_label=q.predicted_label;

    -- Predict using models specific to states:
    SELECT {schema_madlib}.mlp_predict(
        'mlp_model_group',   -- Grouping based model table
        'iris_data',         -- Test data table
        'id',                -- Id column in test table
        'mlp_prediction',    -- Output table for predictions
        'response'           -- Output classes, not probabilities
    );
    SELECT * FROM mlp_prediction;

    -- See {schema_madlib}.mlp_regression('example') for test
    -- and model tables.

    -- Predict using the regression model:
    DROP TABLE IF EXISTS mlp_regress_prediction;
    SELECT madlib.mlp_predict(
         'mlp_regress',               -- Model table
         'lin_housing',               -- Test data table
         'id',                        -- Id column in test table
         'mlp_regress_prediction',    -- Output table for predictions
         'response'                   -- Output values, not probabilities
     );
     SELECT * FROM mlp_regress_prediction;

     -- Predict using the zipcode specific regression models:
     DROP TABLE IF EXISTS mlp_regress_prediction;
     SELECT madlib.mlp_predict(
         'mlp_regress_group',         -- Grouping based model table
         'lin_housing',               -- Test data table
         'id',                        -- Id column in test table
         'mlp_regress_prediction',    -- Output table for predictions
         'response'                   -- Output values, not probabilities
     );
     SELECT * FROM mlp_regress_prediction;

    """.format(**args)

    if not message:
        return summary
    elif message.lower() in ('usage', 'help', '?'):
        return usage
    elif message.lower() == 'example':
        return example
    return """
        No such option. Use "SELECT {schema_madlib}.mlp_predict()" for help.
    """.format(**args)
