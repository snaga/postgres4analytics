"""@file matrix_ops.py_in

@brief Help message functions for all matrix operations

@namespace linalg
"""


matrix_arg_str = """
------------------------------------------------------------
                    MATRIX ARGUMENTS
------------------------------------------------------------
A string containing multiple named arguments of the form "name=value".
This argument is used as a container for multiple parameters related to a single
matrix.

The following parameters are supported for this string argument:
    - row: (Default: 'row_num') Name of the column containing row index of the matrix.
    - col: (Default: 'col_num') Name of the column containing column index of the matrix.
    - val: (Default: 'val') Name of the column containing the entries of the matrix.
                            For a dense matrix, this should be of an ARRAY type.

These string arguments can be NULL if the default values are to be used.

If not provided, 'out_args' uses same value as the first input args.
'out_args' can also include an additional formatting argument:
    - fmt: The format (dense/sparse) for output matrix. If not specified output
            format is inferred from the format of input.
"""

output_str = """
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output table ('matrix_r' above) has the following columns
-- Dense format
    '{row}'       -- Row index for each row of the matrix
    '{val}'       -- Each row vector

-- Sparse format
    '{row}'        -- Row index for each element
    '{col}'        -- Column index for each element
    '{val}'        -- Value for each element

The column names in {} are set using the options provided in 'out_args'.
"""


def _get_help_message(schema_madlib, message, function_name, functionality_str,
                      usage_str, example_str, **kwargs):
    format_dict = dict(locals().items() + globals().items())
    if not message:
        help_string = """
------------------------------------------------------------
                        SUMMARY
------------------------------------------------------------
Functionality: {functionality_str}

For more details on the function usage:
    SELECT {schema_madlib}.{function_name}('usage');
For an example on using this function:
    SELECT {schema_madlib}.{function_name}('example');
For more details on the two input formats (dense or sparse):
    SELECT {schema_madlib}.matrix_info();
        """
    elif message.lower().strip() in ['usage', 'help', '?']:
        help_string = usage_str
    elif message.lower().strip() in ['example', 'examples']:
        help_string = example_str
    else:
        help_string = "No such option. Use {schema_madlib}.{function_name}('usage')"
    return help_string.format(**format_dict)


def matrix_info_help_message(schema_madlib, message, **kwargs):
    """
    Args:
        @param schema_madlib
        @param message
        @param kwargs

    Returns:
        STR.
    """
    dense_format = """
A dense matrix is represented as a distributed collection of 1-D arrays.
An example 3x10 matrix would be the below table:

 row_id |         row_vec
--------+-------------------------
   1    | {{9,6,5,8,5,6,6,3,10,8}}
   2    | {{8,2,2,6,6,10,2,1,9,9}}
   3    | {{3,9,9,9,8,6,3,9,5,6}}

The column names above can be user-defined - the matrix functions provide options
to input these column names. The default names expected are 'row_num' and 'val'.
"""
    sparse_format = """
A sparse matrix is represented using the row and column indices for each
non-zero entry of the matrix. This representation is useful for sparse matrices,
containing multiple zero elements. Given below is an example of a sparse 4x7 matrix
with just 6 out of 28 entries being non-zero.

Note: There should be exactly one tuple that has a NULL for the '<em>value</em>'
column. This tuple gives the dimensionality of the sparse matrix (the
dimensionality cannot be determined just by the entries since the last
row/column could have all zeros).

 row_id | col_id | value
--------+--------+-------
      1 |      1 |     9
      1 |      5 |     6
      1 |      7 |     6
      2 |      1 |     8
      3 |      1 |     3
      3 |      2 |     9
      4 |      7 |     0
(6 rows)

The column names above can be user-defined - the matrix functions provide options
to input these column names. The default names expected are 'row_num', 'col_num'
and 'val'.
    """
    message = message.lower()
    if not message:
        help_string = dense_format + sparse_format + """
            Run "SELECT matrix_info('dense');" or "SELECT matrix_info('sparse');"
            for examples of the specific data format.
        """
    elif message == 'dense':
        help_string = dense_format + """

-- Example to create dense matices
-- These matrices are used in all the matrix operation help message examples.

DROP TABLE IF EXISTS "matrix_A";
CREATE TABLE "matrix_A" (
    row_id integer,
    row_vec integer[]
);
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (1, '{{9,6,5,8,5,6,6,3,10,8}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (2, '{{8,2,2,6,6,10,2,1,9,9}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (3, '{{3,9,9,9,8,6,3,9,5,6}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (4, '{{6,4,2,2,2,7,8,8,0,7}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (5, '{{6,8,9,9,4,6,9,5,7,7}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (6, '{{4,10,7,3,9,5,9,2,3,4}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (7, '{{8,10,7,10,1,9,7,9,8,7}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (8, '{{7,4,5,6,2,8,1,1,4,8}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (9, '{{8,8,8,5,2,6,9,1,8,3}}');
INSERT INTO "matrix_A" (row_id, row_vec) VALUES (10, '{{4,6,3,2,6,4,1,2,3,8}}');

DROP TABLE IF EXISTS "matrix_B";
CREATE TABLE "matrix_B" (
    row_id integer,
    row_vec integer[]
);
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (1, '{{9,10,2,4,6,5,3,7,5,6}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (2, '{{5,3,5,2,8,6,9,7,7,6}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (3, '{{0,1,2,3,2,7,7,3,10,1}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (4, '{{2,9,0,4,3,6,8,6,3,4}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (5, '{{3,8,7,7,0,5,3,9,2,10}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (6, '{{5,3,1,7,6,3,5,3,6,4}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (7, '{{4,8,4,4,2,7,10,0,3,3}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (8, '{{4,6,0,1,3,1,6,6,9,8}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (9, '{{6,5,1,7,2,7,10,6,0,6}}');
INSERT INTO "matrix_B" (row_id, row_vec) VALUES (10, '{{1,4,4,4,8,5,2,8,5,5}}');
"""
    elif message == 'sparse':
        # TODO
        help_string = sparse_format + """
        -- Example data for sparse matrices
CREATE TABLE "mat_A_sparse"(
    "rowNum" integer,
    col_num integer,
    entry integer
);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (1, 1, 9);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (1, 2, 6);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (1, 8, 3);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (1, 9, 10);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (1, 10, 8);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (2, 1, 8);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (2, 2, 2);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (2, 3, 2);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (2, 4, 6);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (2, 6, 6);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (2, 7, 3);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (8, 1, 7);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (9, 3, 8);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (9, 4, 5);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (10, 2, 6);
INSERT INTO "mat_A_sparse" ("rowNum", col_num, entry) VALUES (10, 3, 3);

CREATE TABLE "mat_B_sparse"(
    row_id integer,
    col_id integer,
    val integer
);
INSERT INTO "mat_B_sparse" (row_id, col_id, val) VALUES (1, 1, 9);
INSERT INTO "mat_B_sparse" (row_id, col_id, val) VALUES (1, 8, 3);
INSERT INTO "mat_B_sparse" (row_id, col_id, val) VALUES (2, 2, 2);
INSERT INTO "mat_B_sparse" (row_id, col_id, val) VALUES (2, 3, 2);
INSERT INTO "mat_B_sparse" (row_id, col_id, val) VALUES (2, 4, 6);
INSERT INTO "mat_B_sparse" (row_id, col_id, val) VALUES (10, 2, 6);
INSERT INTO "mat_B_sparse" (row_id, col_id, val) VALUES (10, 3, 3);
        """
    else:
        help_string = "No such option. Use {schema_madlib}.matrix_add('usage')"
    return help_string.format(schema_madlib=schema_madlib)
# ----------------------------------------------------------------------


def matrix_identity_help_message(schema_madlib, message, **kwargs):
    """ Help message for Create an identity matrix
    """
    functionality_str = "Create a square identity matrix of specified dimension"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_identity(
    dim             -- Integer specifying the dimensionality of output.
    'matrix_out'    -- Name of the table to store result matrix
    'out_args'      -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example returns an identity matrix of size 4 x 4

----------------------- Dense format --------------------------------
SELECT madlib.matrix_identity(4, 'mat_r', 'row=row_id, val=val, fmt=dense');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_identity(4, 'mat_r', 'row=row,col=col,val=val, fmt=sparse');
SELECT * FROM mat_r ORDER BY row;
        """
    return _get_help_message(schema_madlib, message, "matrix_identity",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_diag_help_message(schema_madlib, message, **kwargs):
    """ Help message for Creating a diagonal matrix
    """
    functionality_str = "Create a diagonal matrix using provided diagonal elements"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_diag(
    diag_elements   -- The array containing diagonal elements.
    'matrix_out'    -- Name of output matrix.
    'out_args'      -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example creates a diagonal matrix. The output by default is a sparse
-- matrix. A dense matrix can be obtained by using 'fmt=dense'

----------------------- Dense format --------------------------------
SELECT madlib.matrix_diag(array[1.0, 2.5, 3.4, 10, 6.8],
                          'matrix_r', 'row=row_id, val=val, fmt=dense');
SELECT * FROM matrix_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_diag(array[1.0, 2.5, 3.4, 10, 6.8], 'matrix_r', 'row=row_id, col=col_id,val=val');
SELECT * FROM matrix_r ORDER BY row_id;
        """
    return _get_help_message(schema_madlib, message, "matrix_diag",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------------------------


def matrix_extract_diag_help_message(schema_madlib, message, **kwargs):
    """ Help message for main diagonal of the matrix
    """
    functionality_str = "Extract the main diagonal of a square matrix."
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------
SELECT {schema_madlib}.matrix_extract_diag(
    'matrix_in'     -- Name of the table containing input matrix
    'in_args'       -- String argument containing matrix_in arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}

------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is an array containing the main diagonal.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
-----------------------------------------------------------
-- Below example extracts the main diagonal. The function call is the same
-- for dense and sparse matrices.
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense input format --------------------------------
SELECT madlib.matrix_extract_diag('"matrix_A"', 'row=row_id, val=row_vec');

----------------------- Sparse input format --------------------------------
SELECT madlib.matrix_extract_diag('"mat_B_sparse"', 'row=row_id, col=col_id, val=val');
        """
    return _get_help_message(schema_madlib, message, "matrix_extract_diag",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_add_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix addition
    """
    functionality_str = "Compute addition of two matrices"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_add(
    'matrix_a',     -- Name of the table containing 1st matrix
    'a_args',       -- String argument containing matrix_a specific arguments
                    --     (see matrix arguments below for options)
    'matrix_b',     -- Name of the table containing 2nd matrix
    'b_args',       -- String argument containing matrix_b specific arguments
                    --     (see matrix arguments below for options)
    'matrix_out'    -- Name of the table to store result matrix
    'out_args',     -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example computes A + B
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_add('"matrix_A"', 'row=row_id, val=row_vec',
                         '"matrix_B"', 'row=row_id, val=vector',
                         'mat_r', 'val=vector');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_add('"mat_A_sparse"', 'row="rowNum", val=entry',
                         '"mat_B_sparse"', 'row=row_id, col=col_id, val=vector',
                         'matrix_r_sparse', 'col=col_out');
SELECT * FROM matrix_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_add",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_zeros_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix initialization with zeros
    """
    functionality_str = "Create a matrix with all elements set to zero"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------
SELECT {schema_madlib}.matrix_zeros(
    row_dim,        -- The number of row of matrix initialized with zeros
    col_dim,        -- The number of column of matrix initialized with zeros
    'matrix_out'    -- Name of the table to store result matrix
    'out_args',     -- String argument containing matrix_out specific arguments
                    -- (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example returns a matrix initialized with all zeros. The default output
-- format is sparse.

----------------------- Dense format --------------------------------
SELECT madlib.matrix_zeros(5, 4, 'matrix_r_dense', 'row=row_id, val=val, fmt=dense');
SELECT * FROM matrix_r_dense ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_zeros(5, 4, 'matrix_r_sparse', 'row=row_id, col=col_id, val=val');
SELECT * FROM matrix_r_sparse ORDER BY row_id;
        """
    return _get_help_message(schema_madlib, message, "matrix_zeros",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_ones_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix initialization with ones
    """
    functionality_str = "Create a matrix with all elements set to one"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------
SELECT {schema_madlib}.matrix_ones(
    row_dim,        -- The row dimension of output matrix
    col_dim,        -- The column dimension of output matrix
    'matrix_out'    -- Name of output matrix
    'out_args',     -- String argument containing matrix_out specific arguments
                    -- (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
    """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example returns a matrix initialized with all ones. The default
-- output format is sparse.

----------------------- Dense format --------------------------------
SELECT madlib.matrix_ones(5, 4, 'matrix_r_dense', 'row=row_id, val=val, fmt=dense');
SELECT * FROM mat_r_dense ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_ones(3, 2, 'matrix_r_sparse', 'row=row_id, col=col_id, val=val');
SELECT * FROM matrix_r_sparse ORDER BY row_id, col_id;
        """
    return _get_help_message(schema_madlib, message, "matrix_ones",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_sub_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix subtraction
    """
    functionality_str = "Compute subtraction of two matrices"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_sub(
    'matrix_a',     -- Name of the table containing 1st matrix
    'a_args',       -- String argument containing matrix_a specific arguments
                    --     (see matrix arguments below for options)
    'matrix_b',     -- Name of the table containing 2nd matrix
    'b_args',       -- String argument containing matrix_b specific arguments
                    --     (see matrix arguments below for options)
    'matrix_out'    -- Name of the table to store result matrix
    'out_args',     -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example computes A - B
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_sub('"matrix_A"', 'row=row_id, val=row_vec',
                         '"matrix_B"', 'row=row_id, val=vector',
                         'mat_r', 'val=vector');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_sub('"mat_A_sparse"', 'row="rowNum", val=entry',
                         '"mat_B_sparse"', 'row=row_id, col=col_id, val=vector',
                         'matrix_r_sparse', 'col=col_out');
SELECT * FROM matrix_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_sub",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------

def matrix_ndims_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix dimension
    """
    if not message:
        help_string = """
------------------------------------------------------------
                        SUMMARY
------------------------------------------------------------
Functionality: Matrix dimension information

This function provides dimension information of a matrix either in dense or sparse format.

For more details on the function usage:
    SELECT {schema_madlib}.matrix_ndims('usage');
For an example on using this function:
    SELECT {schema_madlib}.matrix_ndims('example');
For more details on the two input formats (dense or sparse):
    SELECT {schema_madlib}.matrix_info();
        """
    elif message.lower().strip() in ['usage', 'help', '?']:
        help_string = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_ndims(
    'matrix_in',    -- Name of the table containing input matrix
    'in_args',      -- String argument containing matrix_in arguments
                    --     (see matrix arguments below for options)
    'is_block'      -- where the table is in block format
);

------------------------------------------------------------
                    MATRIX ARGUMENTS
------------------------------------------------------------
A string containing multiple named arguments of the form "name=value".
This argument is used as a container for multiple parameters related to a single
matrix.

The following parameters are supported for this string argument:
    row: (Default: 'row_num') Name of the column containing row index of the matrix.
    col: (Default: 'col_num') Name of the column containing column index of the matrix.
    val: (Default: 'val') Name of the column containing the entries of the matrix.
                          For a dense matrix, this should be of an ARRAY type.

These string arguments can be NULL if the default values are to be used.

If not provided, out_args uses same value as in_args.

------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
        An array with matrix_in dimension information in format of (number of rows,number of columns)
        """
    elif message.lower().strip() in ['example', 'examples']:
        help_string = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example computes B'

----------------------- Dense format --------------------------------
-- Data for "matrix_B" can be obtained from
--      SELECT matrix_info('dense');

SELECT madlib.matrix_ndims('"mat_B"', 'row=row_id, val=vector');

----------------------- Sparse format --------------------------------
-- Data for "matrix_A_sparse" can be obtained from
--      SELECT matrix_info('sparse');

SELECT madlib.matrix_ndims('"matrix_A_sparse"', 'row="rowNum", col=col_num, val=entry');
        """
    else:
        help_string = "No such option. Use {schema_madlib}.matrix_trans('usage')"
    return help_string.format(schema_madlib=schema_madlib)
# ------------------------------------------------------------------------------


def matrix_elem_mult_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix multiplication by element
    """
    functionality_str = "Compute element-wise multiplication of two matrices"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_elem_mult(
    'matrix_a',     -- Name of the table containing 1st matrix
    'a_args',       -- String argument containing matrix_a specific arguments
                    --     (see matrix arguments below for options)
    'matrix_b',     -- Name of the table containing 2nd matrix
    'b_args',       -- String argument containing matrix_b specific arguments
                    --     (see matrix arguments below for options)
    'matrix_out'    -- Name of the table to store result matrix
    'out_args',     -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example computes A .* B
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_elem_mult('"matrix_A"', 'row=row_id, val=row_vec',
                         '"matrix_B"', 'row=row_id, val=vector',
                         'mat_r', 'val=vector');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_elem_mult('"mat_A_sparse"', 'row="rowNum", val=entry',
                               '"mat_B_sparse"', 'row=row_id, col=col_id, val=vector',
                               'matrix_r_sparse', 'col=col_out');
SELECT * FROM matrix_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_elem_mult",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_mult_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix Multiplicationn
    """
    functionality_str = "Compute multiplication of two matrices"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_mult(
    'matrix_a',     -- Name of the table containing 1st matrix
    'a_args',       -- String argument containing matrix_a specific arguments
                    --     (see matrix arguments below for options)
    'matrix_b',     -- Name of the table containing 2nd matrix
    'b_args',       -- String argument containing matrix_b specific arguments
                    --     (see matrix arguments below for options)
    'matrix_out'    -- Name of the table to store result matrix
    'out_args',     -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example computes A * B
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_mult('"matrix_A"', 'row=row_id, val=row_vec',
                         '"matrix_B"', 'row=row_id, val=vector',
                         'mat_r', 'val=vector');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_mult('"mat_A_sparse"', 'row="rowNum", val=entry',
                          '"mat_B_sparse"', 'row=row_id, col=col_id, val=vector',
                          'matrix_r_sparse', 'col=col_out');
SELECT * FROM matrix_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_mult",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_trans_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix transposition
    """
    functionality_str = "Compute transpose of a matrix"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_trans(
    'matrix_in',     -- Name of the table containing the matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                    --     (see matrix arguments below for options)
    'matrix_out'    -- Name of the table to store result matrix
    'out_args',     -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example computes A'
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_trans('"matrix_A"', 'row=row_id, val=row_vec',
                           'mat_r', 'val=vector');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_trans('"mat_A_sparse"', 'row="rowNum", val=entry',
                           'matrix_r_sparse', 'col=col_out');
SELECT * FROM matrix_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_trans",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_extract_row_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix row extraction
    """
    functionality_str = "Extract row from a matrix"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_extract_row(
    'matrix_in',    -- Name of the table containing input matrix
    'in_args',      -- String argument containing matrix_in specific arguments
                    --     (see matrix arguments below for options)
    'index'         -- Index of the desired row
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_extract_row('"mat_A"', 'row=row_id, val=row_vec', 0);

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_extract_row('"mat_A_sparse"', 'row="rowNum", val=entry', 0);
        """
    return _get_help_message(schema_madlib, message, "matrix_extract_row",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_extract_col_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix column extraction
    """
    functionality_str = "Extract col from a matrix"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_extract_col(
    'matrix_in',    -- Name of the table containing input matrix
    'in_args',      -- String argument containing matrix_in specific arguments
                    --     (see matrix arguments below for options)
    'index'         -- Index of the desired col
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_extract_col('"mat_A"', 'row=row_id, val=row_vec', 0);

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_extract_col('"mat_A_sparse"', 'row="rowNum", val=entry', 0);
        """
    return _get_help_message(schema_madlib, message, "matrix_extract_col",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def _min_max_help_message(schema_madlib, message, suffix, **kwargs):
    """ Common help message for Matrix min and max
    """
    functionality_str = "Compute {0} along a specified dimension".format(suffix)
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_{0}(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'dim'            -- Dimension. Should either be 1 or 2. This value indicates
                        the dimension to operate along i.e. whose length reduces
                        to 1 in the result
    'matrix_r'       -- Name of the table to store result matrix
    'fetch_index'    -- If true, corresponding index of each {0} value is returned
);

{{matrix_arg_str}}

------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output table ('matrix_r' above) has the following columns

    '{0}'       -- Vector of ordered {0} values
    'index'     -- Vector of ordered corresponding indices of {0} values
        """.format(suffix)
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_{0}('"mat_A"', 'row=row_id, val=row_vec', 1, 'mat_r', true, true);
SELECT madlib.matrix_{0}('"mat_A"', 'row=row_id, val=row_vec', 2, 'mat_r', true, true);

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_{0}('"mat_A_sparse"', 'row="rowNum", val=entry', 1, 'mat_r', true, true);
SELECT madlib.matrix_{0}('"mat_A_sparse"', 'row="rowNum", val=entry', 2, 'mat_r', true, true);
        """.format(suffix)
    return _get_help_message(schema_madlib, message, "matrix_" + suffix,
                             functionality_str, usage_str, example_str)


def matrix_max_help_message(schema_madlib, message, **kwargs):
    return _min_max_help_message(schema_madlib, message, 'max')


def matrix_min_help_message(schema_madlib, message, **kwargs):
    return _min_max_help_message(schema_madlib, message, 'min')
# ------------------------------------------------------------

def matrix_norm_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix norm 
    """
    if not message:
        help_string = """
------------------------------------------------------------
                        SUMMARY
------------------------------------------------------------
Functionality: Matrix norm 

This function computes matrix norm values either in dense or sparse format.

For more details on the function usage:
    SELECT {schema_madlib}.matrix_norm('usage');
For an example on using this function:
    SELECT {schema_madlib}.matrix_norm('example');
For more details on the two input formats (dense or sparse):
    SELECT {schema_madlib}.matrix_info();
        """
    elif message.lower().strip() in ['usage', 'help', '?']:
        help_string = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_norm(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'norm_type'      -- Optional, default 'fro'. It supports
                        'one' or 'o'                1 norm
                        <float(>0)>                 element-wise norm
                        'inf' or 'i'                infinite norm
                        'max' or 'm'                max absolute value norm
                        'fro' or 'f'                F norm
);

------------------------------------------------------------
                    MATRIX ARGUMENTS
------------------------------------------------------------
A string containing multiple named arguments of the form "name=value".
This argument is used as a container for multiple parameters related to a single
matrix.

The following parameters are supported for this string argument:
    - row: (Default: 'row_num') Name of the column containing row index of the matrix.
    - col: (Default: 'col_num') Name of the column containing column index of the matrix.
    - val: (Default: 'val') Name of the column containing the entries of the matrix.
                            For a dense matrix, this should be of an ARRAY type.

These string arguments can be NULL if the default values are to be used.

------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is a value which computes matrix norm.
        """
    elif message.lower().strip() in ['example', 'examples']:
        help_string = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Below example computes matrix norm 

----------------------- Dense format --------------------------------
-- Data for "matrix_A" can be obtained from
--      SELECT matrix_info('dense');

SELECT madlib.matrix_norm('"mat_A"', 'row=row_id, val=row_vec', '2');
SELECT madlib.matrix_norm('"mat_A"', 'row=row_id, val=row_vec', 'inf');

----------------------- Sparse format --------------------------------
-- Data for "matrix_A_sparse" can be obtained from
--      SELECT matrix_info('sparse');

SELECT madlib.matrix_norm('"mat_A_sparse"', 'row="rowNum", val=entry', '2');
SELECT madlib.matrix_norm('"mat_A_sparse"', 'row="rowNum", val=entry', 'm');
        """
    else:
        help_string = "No such option. Use {schema_madlib}.matrix_norm('usage')"
    return help_string.format(schema_madlib=schema_madlib)
# ------------------------------------------------------------

def _agg_help_message(schema_madlib, message, suffix, **kwargs):
    """ Common help message for aggregate operations on Matrix
    """
    functionality_str = "Compute the {0} along a specific dimension".format(suffix)

    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_{0}(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'dim'            -- Dimension. Should either be 1 or 2. This value indicates
                        the dimension to operate along i.e. whose length reduces
                        to 1 in the result
);

{{matrix_arg_str}}

------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is a vector containing the {0} along given dimension.
        """.format(suffix)
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_{0}('"mat_A"', 'row=row_id, val=row_vec', 1);
SELECT madlib.matrix_{0}('"mat_A"', 'row=row_id, val=row_vec', 2);

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_{0}('"mat_A_sparse"', 'row="rowNum", val=entry', 1);
SELECT madlib.matrix_{0}('"mat_A_sparse"', 'row="rowNum", val=entry', 2);
        """
    return _get_help_message(schema_madlib, message, "matrix_" + suffix,
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_sum_help_message(schema_madlib, message, **kwargs):
    return _agg_help_message(schema_madlib, message, "sum")


def matrix_mean_help_message(schema_madlib, message, **kwargs):
    return _agg_help_message(schema_madlib, message, "mean")


def matrix_scalar_mult_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix scalar multiply
    """
    functionality_str = "Compute multiplication of matrix with a scalar"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------
SELECT {schema_madlib}.matrix_scalar_mult(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'scalar'         -- Scalar value used to be multiplied with matrix_in
    'matrix_out',    -- Name of the table containing result
    'out_args',      -- String argument containing matrix_out specific arguments
                     --    (see matrix arguments below for options)
);

{matrix_arg_str}
{output_str}
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_scalar_mult('"mat_A"', 'row=row_id, val=row_vec',
                                 10, 'mat_r', 'val=vector');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_scalar_mult('"mat_A_sparse"', 'row="rowNum", val=entry',
                                 10, 'matrix_r_sparse', 'col=col_out');
SELECT * FROM matrix_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_scalar_mult",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_vec_mult_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix vector multiply
    """
    functionality_str = "Compute multiplication of matrix with a vector"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_vec_mult(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'vector'         -- Vector value used to be multiplied with matrix_in
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is an array representing the result of the vector multiplication.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_vec_mult('"mat_A"', 'row=row_id, val=row_vec',
                              array[1,2,3,4,5,6,7,8,9,10]::float8[]);
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_scalar_mult('"mat_A_sparse"', 'row="rowNum", val=entry',
                                 array[1,2,3,4,5,6,7]::float8[]);
SELECT * FROM matrix_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_vec_mult",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_eigen_help_message(schema_madlib, message, **kwargs):
    """ Help message for Matrix eigen values extraction 
    """
    functionality_str = "Extract eigen values of matrix"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_eigen(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'matrix_out'     -- Name of the table to store result matrix
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output are eigen values of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_eigen('"mat_A"', 'row=row_id, val=row_vec', 'mat_r');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_eigen('"mat_A_sparse"', 'row="rowNum", val=entry', 'mat_r');
SELECT * FROM mat_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_eigen",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_pinv_help_message(schema_madlib, message, **kwargs):
    """ Help message for generic inverse of matrix
    """
    functionality_str = "Generic inverse of matrix"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_pinv(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'matrix_out',    -- Name of the table to store result matrix
    'out_args'       -- String argument containing matrix_out specific arguments
                     --    (see matrix arguments below for options)
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is generic inverse of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_pinv('"mat_A"', 'row=row_id, val=row_vec', 'mat_r');
SELECT * FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_pinv('"mat_A_sparse"', 'row="rowNum", val=entry', 'mat_r');
SELECT * FROM mat_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_pinv",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_cholesky_help_message(schema_madlib, message, **kwargs):
    """ Help message for cholesky decomposition of matrix
    """
    functionality_str = "Matrix cholesky decomposition"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_cholesky(
    'matrix_in',        -- Name of the table containing input matrix
    'in_args',          -- String argument containing matrix_in specific arguments
                        --    (see matrix arguments below for options)
    'matrix_out_prefix' -- Name prefix of the table to store result matrix L
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is cholesky decomposition of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_cholesky('"mat_A"', 'row=row_id, val=row_vec', 'mat_result');
SELECT * FROM mat_result_p ORDER BY row_id;
SELECT * FROM mat_result_l ORDER BY row_id;
SELECT * FROM mat_result_d ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_cholesky('"mat_A_sparse"', 'row="rowNum", val=entry', 'mat_result');
SELECT * FROM mat_result_p ORDER BY "rowNum";
SELECT * FROM mat_result_l ORDER BY "rowNum";
SELECT * FROM mat_result_d ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_cholesky",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_qr_help_message(schema_madlib, message, **kwargs):
    """ Help message for QR decomposition of matrix
    """
    functionality_str = "Matrix QR decomposition"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_qr(
    'matrix_in',            -- Name of the table containing input matrix
    'in_args',              -- String argument containing matrix_in specific arguments
                            --    (see matrix arguments below for options)
    'matrix_out_prefix',    -- Name prefix of the table to store result matrix
    'out_args'              -- String argument containing matrix_r specific arguments
                            --    (see matrix arguments below for options)
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is QR decomposition of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_qr('"mat_A"', 'row=row_id, val=row_vec', 'mat_result');
SELECT * FROM mat_result_q ORDER BY row_id;
SELECT * FROM mat_result_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_qr('"mat_A_sparse"', 'row="rowNum", val=entry', 'mat_q', 'mat_r');
SELECT * FROM mat_result_q ORDER BY "rowNum";
SELECT * FROM mat_result_r ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_qr",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_lu_help_message(schema_madlib, message, **kwargs):
    """ Help message for LU decomposition of matrix
    """
    functionality_str = "Matrix LU decomposition"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_lu(
    'matrix_in',            -- Name of the table containing input matrix
    'in_args',              -- String argument containing matrix_in specific arguments
                            --    (see matrix arguments below for options)
    'matrix_out_prefix',    -- Name of the table to store result matrix P
    'out_args'              -- String argument containing matrix_p specific arguments
                            --    (see matrix arguments below for options)
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is LU decomposition of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_lu('"mat_A"', 'row=row_id, val=row_vec', 'mat_result');
SELECT * FROM mat_result_p ORDER BY row_id;
SELECT * FROM mat_result_l ORDER BY row_id;
SELECT * FROM mat_result_u ORDER BY row_id;
SELECT * FROM mat_result_q ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_lu('"mat_A_sparse"', 'row="rowNum", val=entry', 'mat_result');
SELECT * FROM mat_result_p ORDER BY "rowNum";
SELECT * FROM mat_result_l ORDER BY "rowNum";
SELECT * FROM mat_result_u ORDER BY "rowNum";
SELECT * FROM mat_result_q ORDER BY "rowNum";
        """
    return _get_help_message(schema_madlib, message, "matrix_lu",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_nuclear_norm_help_message(schema_madlib, message, **kwargs):
    """ Help message for computing nuclear norm of matrix
    """
    functionality_str = "Matrix nuclear norm computing"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_nuclear_norm(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is nuclear norm computing of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_nuclear_norm('"mat_A"', 'row=row_id, val=row_vec');

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_nuclear_norm('"mat_A_sparse"', 'row="rowNum", val=entry');
        """
    return _get_help_message(schema_madlib, message, "matrix_nuclear_norm",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_rank_help_message(schema_madlib, message, **kwargs):
    """ Help message for computing rank of matrix
    """
    functionality_str = "Matrix rank computing"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_rank(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is rank computing of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_rank('"mat_A"', 'row=row_id, val=row_vec');

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_rank('"mat_A_sparse"', 'row="rowNum", val=entry');
        """
    return _get_help_message(schema_madlib, message, "matrix_rank",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------


def matrix_inverse_help_message(schema_madlib, message, **kwargs):
    """ Help message for computing inverse of matrix
    """
    functionality_str = "Matrix inverse computing"
    usage_str = """
------------------------------------------------------------
                        USAGE
------------------------------------------------------------

SELECT {schema_madlib}.matrix_inverse(
    'matrix_in',     -- Name of the table containing input matrix
    'in_args',       -- String argument containing matrix_in specific arguments
                     --    (see matrix arguments below for options)
    'matrix_out'    -- Name of the table to store result matrix
    'out_args'      -- String argument containing matrix_out specific arguments
                    --     (see matrix arguments below for options)
);

{matrix_arg_str}
------------------------------------------------------------
                        OUTPUT
------------------------------------------------------------
The output is inverse of the matrix.
        """
    example_str = """
------------------------------------------------------------
                        EXAMPLE
------------------------------------------------------------
-- Use matrix_info() to get the data/table definitions for below matrices

----------------------- Dense format --------------------------------
SELECT madlib.matrix_inverse('"mat_A"', 'row=row_id, val=row_vec', 'mat_r');
SELECT row_vec FROM mat_r ORDER BY row_id;

----------------------- Sparse format --------------------------------
SELECT madlib.matrix_inverse('"mat_A_sparse"', 'row="rowNum", val=entry', 'mat_r');
SELECT row_vec FROM mat_r ORDER BY row_id;
        """
    return _get_help_message(schema_madlib, message, "matrix_inverse",
                             functionality_str, usage_str, example_str)
# ------------------------------------------------------------
